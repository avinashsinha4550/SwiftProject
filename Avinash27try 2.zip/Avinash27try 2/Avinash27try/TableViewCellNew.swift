//
//  TableViewCellNew.swift
//  Avinash27try
//
//  Created by Satya on 13/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class TableViewCellNew: UITableViewCell {
    @IBOutlet weak var textNameFielder: UILabel!
    
    @IBOutlet weak var UsernameTextField: UILabel!
   
    @IBOutlet weak var imageViewDetails: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func buttonSelectedAndChangeed()
    {
        print("Avinash")
    }

}
