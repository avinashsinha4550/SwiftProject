//
//  TextFieldDoneButton.swift
//  Avinash27try
//
//  Created by Satya on 12/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import Foundation
import UIKit
extension UITextField
{
    func addDoneButtonOnKeyboard(){
            let toolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        toolbar.barStyle = .default
        let clear: UIBarButtonItem = UIBarButtonItem(title: "Clear", style: .plain, target: self, action: #selector(ClickedClear))
            let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
            let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(ClickedDone))
        toolbar.setItems([clear,flexSpace,done], animated: true)
        toolbar.sizeToFit()
        self.inputAccessoryView = toolbar
        }
    @objc  func ClickedClear()
    {
        self.text = " "
    }
    @objc func ClickedDone()
    {
        self.endEditing(true)
    }
    
}
