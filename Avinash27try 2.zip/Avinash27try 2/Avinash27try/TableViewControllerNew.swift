//
//  TableViewControllerNew.swift
//  Avinash27try
//
//  Created by Satya on 13/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class TableViewControllerNew: UITableViewController, UIPopoverPresentationControllerDelegate {
    @IBOutlet var tableViewController: UITableView!
   
    let arrayEmail = UserDefaults.standard.value(forKey: "keyEmail") as? [String] ?? [""]
    let arrayUsername = UserDefaults.standard.value(forKey: "keyUsername") as? [String] ?? [""]
    let imageViewArray = UserDefaults.standard.value(forKey: "arrayImage") as? [Data]
 
    override func viewDidLoad() {
        super.viewDidLoad()
     
     
    }

    

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return arrayEmail.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? TableViewCellNew
      
            if let imageData = imageViewArray?[indexPath.row],
             let image = UIImage(data: (imageData as NSData) as Data){
              
             cell?.imageViewDetails?.image = image
                cell?.imageViewDetails.layer.cornerRadius = (cell?.imageViewDetails.bounds.size.height)!/2
    
        }
        cell?.textNameFielder.text = arrayEmail[indexPath.row]
        cell?.UsernameTextField.text = arrayUsername[indexPath.row]
       
     
      
        return cell!
        
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let popoverContent =  self.storyboard?.instantiateViewController(withIdentifier: "logindetaillist") as? LoginDetailsList else { return  }
        let nav = UINavigationController(rootViewController: popoverContent)
          nav.modalPresentationStyle = UIModalPresentationStyle.popover
        let popover = nav.popoverPresentationController
        popoverContent.preferredContentSize = CGSize(width: 100,height: 100)
        popover?.delegate = self
        popover?.sourceView = self.view
        popover?.sourceRect = CGRect(x: 100,y: 100,width: 0,height: 0)
        self.present(nav, animated: true, completion: nil)
        UserDefaults.standard.set(indexPath.row, forKey: "rowSelected")
    }
}
      
