//
//  LoginViewController.swift
//  Avinash27try
//
//  Created by Satya on 04/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit
import SideMenu
class LoginViewController: UIViewController {
    //MARK:-IBOutlet
//    let menu  = SideMenuNavigationController(rootViewController: LoginViewController())
    @IBOutlet weak var MenuActionButton: UIBarButtonItem!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var createAccount: UIButton!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var imageChange: UIImageView!
    let admin:String = "a"
    let adminpassword:String = "a"
    //MARK:-variable
    //    var count:Int = 0
    
    //5 fields
    @IBOutlet weak var loginAction: UIButton!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        loginAction?.layer.cornerRadius = loginAction.bounds.size.height/2
        emailTextField?.layer.cornerRadius = emailTextField.bounds.size.height/2
        passwordTextField?.layer.cornerRadius = passwordTextField.bounds.size.height/2
        emailTextField?.addDoneButtonOnKeyboard()
        passwordTextField?.addDoneButtonOnKeyboard()
        title = "Login Page"
    }
    //MARK:-MenuButton
    @IBAction func MenuButton(_ sender: UIButton) {
//        present(menu, animated: true, completion: nil)
    }
    //MARK:- Buttons Actions
    @IBAction func CreateAccount(_ sender: Any) {
        
        guard let registrationPage =  self.storyboard?.instantiateViewController(withIdentifier: "RegistrationPage") as? ViewController else { return  }
        self.navigationController?.pushViewController(registrationPage, animated: true)
    }
    //MARK:-IBOutlet loginAction
    @IBAction func loginAction(_ sender: UIButton) {
        AdminTableViewControllerNew()
        print(UserDefaults.standard.value(forKey: "DictionaryElement"))
        if emailTextField.text?.count ?? 0 > 0 && passwordTextField.text?.count ?? 0 > 0 {
           
            
            if validatioon() {
                logindetilpage()
//                imageChange.image = UserDefaults.standard.
                print(String(validatioon()))
            }
        }else{
            print("enter blank")
            showSimpleAlert()
        }
     
        
    }
    //MARK:-IBOutlet ForgetPasswordButton
    @IBAction func ForgetPasswordButton(sender: UIButton) {
        UserDefaults.standard.set(emailTextField.text!, forKey: "email")
        guard let forgetpassword =  self.storyboard?.instantiateViewController(withIdentifier: "forgetpasswordID") as? ForgetPasswordClass else { return  }
        self.navigationController?.pushViewController(forgetpassword, animated: true)
    }
    func logindetilpage() {
        guard let loginDetailList = self.storyboard?.instantiateViewController(withIdentifier: "logindetaillist") as? LoginDetailsList else {
        return }
        self.navigationController?.pushViewController(loginDetailList, animated: true)
        UserDefaults.standard.set(emailTextField.text!, forKey: "email")
        UserDefaults.standard.set(passwordTextField.text!, forKey: "password")
        
        
    }
   
    
    
    
    //MARK:-function validation
    func validatioon() -> Bool  {
   
        if emailTextField.text! == UserDefaults.standard.string(forKey:emailTextField.text!)
        {
            if  passwordTextField.text! == UserDefaults.standard.string(forKey: passwordTextField.text!) {
                return true
            }else{
                passwordTextField.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
                return false
            }
           
        }
        else
        {
            emailTextField.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
        }
        passwordTextField.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
     
    return false
    }
    func showSimpleAlert() {
        let alert = UIAlertController(title: "Blank Field?", message: "Don't leave blank Fields",         preferredStyle: UIAlertController.Style.alert)

        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
               //Cancel Action
           }))
           alert.addAction(UIAlertAction(title: "ok",
                                         style: UIAlertAction.Style.default,
                                         handler: {(_: UIAlertAction!) in
                                           //ok  action
           }))
           self.present(alert, animated: true, completion: nil)
       }
    func  AdminTableViewControllerNew() {
        if emailTextField.text! == admin && passwordTextField.text! == adminpassword {
            guard let adminTableViewControllerNew = self.storyboard?.instantiateViewController(withIdentifier: "tableViewControllerNew") as? TableViewControllerNew else {
            return }
            self.navigationController?.pushViewController(adminTableViewControllerNew, animated: true)
            
        }
    }
}
