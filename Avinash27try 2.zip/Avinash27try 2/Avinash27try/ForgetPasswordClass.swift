//
//  ForgetPasswordClass.swift
//  Avinash27try
//
//  Created by Satya on 09/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class ForgetPasswordClass: UIViewController {

    @IBOutlet weak var forgetPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        forgetPassword?.addDoneButtonOnKeyboard()
        title = "Forget Password"
       
    }
    @IBAction func ContinuePasswordReset(_ sender: Any) {
        forgetreattemtPassword()
    }
    func forgetreattemtPassword()   {
        if forgetPassword.text! == UserDefaults.standard.string(forKey: "email"){
            guard let passwordChange =  self.storyboard?.instantiateViewController(withIdentifier: "passwordChange") as? PasswordChange else {
                return
            }
            self.navigationController?.pushViewController(passwordChange, animated: true)
             
        }else{
            showSimpleAlert()
        }
    }

    func showSimpleAlert() {
        let alert = UIAlertController(title: "Wrong", message: "enter Valid Email",         preferredStyle: UIAlertController.Style.alert)

        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
               //Cancel Action
           }))
           alert.addAction(UIAlertAction(title: "ok",
                                         style: UIAlertAction.Style.default,
                                         handler: {(_: UIAlertAction!) in
                                           //ok  action
           }))
           self.present(alert, animated: true, completion: nil)
       }

}
