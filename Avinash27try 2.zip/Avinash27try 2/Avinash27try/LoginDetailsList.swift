//
//  LoginDetailsList.swift
//  Avinash27try
//
//  Created by Satya on 12/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class LoginDetailsList: UIViewController {
    var arraye:String = ""
    var i:Int = 0
    var array:[String: Any] = ["": (Any).self]
    let userDefaultData1:[[String: Any]] = [["": (Any).self]]
    @IBOutlet weak var editdataElement: UIButton!
    @IBOutlet weak var detailList: UILabel!
    @IBOutlet weak var passwordlogin: UILabel!
    @IBOutlet weak var emaillogin: UILabel!
    @IBOutlet weak var phoneno: UILabel!
    @IBOutlet weak var firstname: UILabel!
    @IBOutlet weak var lastname: UILabel!
    @IBOutlet weak var Dob: UILabel!
    @IBOutlet weak var nationality: UILabel!
    @IBOutlet weak var working: UILabel!
    @IBOutlet weak var gender: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        i = UserDefaults.standard.integer(forKey: "rowSelected")
        print(i)
        
        let userDefaultData = UserDefaults.standard.value(forKey: "DictionaryElement") as?[[String: Any]]
        
        if let arrayElement = userDefaultData?[i]{
            emaillogin.text! = arrayElement["Email"] as? String ?? " "
            firstname.text! = arrayElement["Username"] as? String ?? " "
            lastname.text! = arrayElement["lastname"] as? String ?? " "
            phoneno.text! = arrayElement["Phoneno"] as? String ?? " "
//            Dob.text! = arrayElement["DOB"] as? String ?? " "
//            nationality.text! = arrayElement["Natinality"] as? String ?? " "
//            working.text! = arrayElement["Working"] as? String ?? " "
//            gender.text! = arrayElement["Gender"] as? String ?? " "
        }
 
    }
    
    @IBAction func EditElement(_ sender: Any) {
        PopUpViewEditData()
        print("Avinsh")
    }
    
    func PopUpViewEditData()  {
        
        let editDetails = UIAlertController(title: "Edit Details", message: "", preferredStyle: UIAlertController.Style.alert)
  
                
        let actionEdit = UIAlertAction(title: "Done",style: .default) { [self]
               (alertAction) in
            let emailAddressEdit  = editDetails.textFields![0] as UITextField
               let userNameEdit  = editDetails.textFields![1] as UITextField
            
            arraye = emailAddressEdit.text!
               
           }
        editDetails.addTextField { (emailAddressEdit) in
            emailAddressEdit.placeholder = "Enter Email Address"
               editDetails.addTextField { (userNameEdit) in
                userNameEdit.placeholder = "Enter Username"
    
               }
               
               editDetails.addAction(actionEdit)
           

            }
          
        var arrayelements1 = userDefaultData1[i]
      arrayelements1["Email"] = arraye
        
               self.present(editDetails,animated: true, completion: nil)
           }
}

