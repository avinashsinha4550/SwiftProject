//
//  TableViewTableViewCell.swift
//  Avinash27try
//
//  Created by Satya on 13/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class TableViewTableViewCell: UITableViewCell {

    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var labelname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

    @IBAction func AddButtonClicked(_ sender: Any) {
        print("Avinsh")
    }
}
