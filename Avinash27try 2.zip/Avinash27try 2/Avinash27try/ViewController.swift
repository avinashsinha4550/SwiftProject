//
//  ViewController.swift
//  Avinash27try
//
//  Created by Brad on 27/09/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit
import SwiftUI
import SideMenu


class ViewController: UIViewController {
    //MARK:- variable
    var genderDetails:String = ""
    var hobbiesArray:[String] = []
    var nationalitySelected:String = ""
    var areuWorkingSelected:String = ""
    var submitValidationresult:Int = 0
    var imageView:UIImageView?
    var arrayString:[String] = []
    var arrayStringEmail:[String] = []
    var arrayStringUsername:[String] = []
    var arrayImageArray:[Data?] = []
    var dictinaryElementRegistration:[[String: Any]] = []
   
    //4 fields
   //MARK:- Iboutlet

    @IBOutlet weak var scrollViewModify: UIScrollView!
    @IBOutlet weak var imageSelection: UIButton!
    @IBOutlet weak var loginPageOutlet: UIButton!
    @IBOutlet weak var passwordRegistration: UITextField!
    @IBOutlet weak var dobRegistraion: UITextField!
    @IBOutlet weak var areuWorking: UISegmentedControl!
    @IBOutlet weak var Imageselection: UIImageView!
    
    @IBOutlet weak var ferf: UISegmentedControl!
    
    @IBOutlet weak var gradianntView: UIView!
    @IBOutlet weak var MaleRadioBtn: UIButton!
    @IBOutlet weak var otheRadioBtn: UIButton!
    @IBOutlet weak var hobbiesComputer: UIButton!
    @IBOutlet weak var hobbiesSwimming: UIButton!
    @IBOutlet weak var hobbiesAthelit: UIButton!
    @IBOutlet weak var hobbiesCricket: UIButton!
    @IBOutlet weak var otherRadioButton: UIButton!
    
    @IBOutlet weak var femaleGenderradio: UIButton!
    
    @IBOutlet weak var submitErrorButton: UIButton!
    @IBOutlet weak var lastNameUsers: UITextField!
    @IBOutlet weak var userFirstname: UITextField!
    @IBOutlet weak var phoneNumberValidation: UITextField!
    @IBOutlet weak var emaiUserName: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emaiUserName?.addDoneButtonOnKeyboard()
        passwordRegistration?.addDoneButtonOnKeyboard()
        userFirstname?.addDoneButtonOnKeyboard()
        lastNameUsers?.addDoneButtonOnKeyboard()
        phoneNumberValidation?.addDoneButtonOnKeyboard()
        dobRegistraion?.addDoneButtonOnKeyboard()
//        let sideMenuViewController = SideMenuNavigationController(rootViewController: LoginViewController)
//        present(menu, animated: true, completion: nil)
    
        Imageselection?.layer.cornerRadius = Imageselection?.bounds.size.height ?? 50/2
      let ImageVieworiginal = UIImage(named: "backoriginal")
        let ImageView = UIImageView()
        ImageView.image = ImageVieworiginal
        ImageView.contentMode = .scaleAspectFit
        loginPageOutlet?.layer.cornerRadius = loginPageOutlet?.bounds.size.height ?? 50/2
        submitErrorButton?.layer.cornerRadius = submitErrorButton?.bounds.size.height ?? 50/2
        self.view.backgroundColor = UIColor(patternImage: ImageView.image ?? UIImage())
        title = "Registration Page"
        emaiUserName?.setLeftIcon(UIImage(systemName: "envelope.fill") ?? UIImage())
        lastNameUsers?.setLeftIcon(UIImage(systemName: "person.crop.circle") ?? UIImage())
        userFirstname?.setLeftIcon(UIImage(systemName: "person.crop.circle") ?? UIImage())
        phoneNumberValidation?.setLeftIcon(UIImage(systemName: "phone.circle") ?? UIImage())
        passwordRegistration?.setLeftIcon(UIImage(systemName: "eye") ?? UIImage())
        
    }

    @IBAction func SegmentNationality(_ sender: Any) {
        switch ferf.selectedSegmentIndex{
        case 0:
            nationalitySelected = "Indian"
            
        case 1:
           nationalitySelected = "others"
        default:
            break
            
        }
    }
    //MARK:-HObbies
    @IBAction func HobbiesCheckbox(_ sender: UIButton) {
       
        
        sender.isSelected = !sender.isSelected

        if sender.isSelected
        {
//         <#T##String#>))
            sender.setImage( UIImage(systemName: "squareshape.fill"),for: UIControl.State.normal)
            sender.tintColor = UIColor.link
        }else
        {
            sender.setImage( UIImage(systemName: "squareshape"),for: UIControl.State.normal)
        }
        
        if hobbiesArray.contains(sender.titleLabel?.text ?? "") {
            hobbiesArray=hobbiesArray.filter{ $0 != sender.titleLabel?.text }
        } else {
        hobbiesArray.append(sender.titleLabel?.text ?? "")
        }
       

    }
    //MARK:-Areuworking
    @IBAction func Areuworking(_ sender: Any) {
        switch areuWorking.selectedSegmentIndex{
        case 0:
            areuWorkingSelected = "Yes"
            
        case 1:
            areuWorkingSelected = "No"
        case 2:
            areuWorkingSelected = "Not yet"
        default:
            break
            
        }
    }
    //MARK:-Emailsubmitvalidation
    func Emailsubmitvalidation()->String  {
        let EmailId:String = emaiUserName.text!
        
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        if emailPredicate.evaluate(with: EmailId) {
            
            return EmailId
        }else
        {
            
            return "Enter Corret email Id"
        }
    }
    //MARK:-Passwordsubmitvalidation
    func Passwordsubmitvalidation()->String  {
        let PasswordId:String = passwordRegistration.text!
        
        let passwordFormat = "[A-Za-z0-9]{2,10}"
        let passwordPredicate = NSPredicate(format:"SELF MATCHES %@", passwordFormat)
        if passwordPredicate.evaluate(with: PasswordId) {
            return PasswordId
        }else
        {
           return "Enter Corret password"
        }
//        PasswordRegistration.text=""
    }
    //MARK:-phonesubmitvalidation
    func phonesubmitvalidation()->String  {
        let PhoneId:String = phoneNumberValidation.text!
        let PHONE_REGEX = "[0-9]{10}"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        if  phoneTest.evaluate(with: PhoneId) {
            return PhoneId
        }
        else
        {
            return "Invalid phone number"
        }

    }
    //MARK:-Firstnamesubmitvalidation
    func Firstnamesubmitvalidation()->String  {
        let FirtnameId:String = userFirstname.text!
        let USER_REGEX = "[A-Za-z]{2,64}"
        let USERTest = NSPredicate(format: "SELF MATCHES %@", USER_REGEX)
        if  USERTest.evaluate(with: FirtnameId) {

                
           return FirtnameId
        }
        else
        {
            userFirstname.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 3, revert: true)
            return "Invalid Firstname"
        }

    }
    //MARK:-Lastnamesubmitvalidation
    func Lastnamesubmitvalidation()->String  {
        let LastnameId:String = lastNameUsers.text!
        let USERLAST_REGEX = "[A-Za-z]{2,64}"
        let USERLastTest = NSPredicate(format: "SELF MATCHES %@", USERLAST_REGEX)
        if  USERLastTest.evaluate(with: LastnameId) {
           return LastnameId
        }
        else
        {
            return "Invalid Lastname"
        }

    }
    //MARK:-DOB
    func DOB()->String {
        let DOBID:String = dobRegistraion.text!
        let DOB = "[1-9]{2}+/[1-9]{1}+/[0-9]{4}"
        let USSERdob = NSPredicate(format: "SELF MATCHES %@", DOB)
        if  USSERdob.evaluate(with: DOBID) {
            return DOBID
        }
        else
        {
            return DOBID
        }
    }
    //MARK:-GenderButton
    @IBAction func GenderButton(_ sender: UIButton) {
        var trueValiDationCount:Int = 0
     MaleRadioBtn.setImage( UIImage(systemName: "circle"),for: UIControl.State.normal)
    femaleGenderradio.setImage( UIImage(systemName: "circle"),for: UIControl.State.normal)
       otheRadioBtn.setImage( UIImage(systemName: "circle"),for: UIControl.State.normal)
        sender.setImage( UIImage(systemName: "circle.fill"),for: UIControl.State.normal)
        sender.tintColor = UIColor.link
        genderDetails = sender.titleLabel?.text ?? ""
        if userFirstname.text! == Firstnamesubmitvalidation() {
        
            trueValiDationCount = trueValiDationCount + 1
           // print(TrueValidationCount)
        }else{
           
        }
        if lastNameUsers.text! == Lastnamesubmitvalidation() {
         
            trueValiDationCount = trueValiDationCount + 1
        }else{
            
        }
        if emaiUserName.text! == Emailsubmitvalidation() {
        
            trueValiDationCount = trueValiDationCount + 1
        }else{
           
        }
        if passwordRegistration.text! == Passwordsubmitvalidation() {
           
            trueValiDationCount = trueValiDationCount + 1
        }else{
           
        }
        if dobRegistraion.text! == DOB() {
          
        }else{
           
        }
        if phoneNumberValidation.text! == phonesubmitvalidation() {
          
            trueValiDationCount = trueValiDationCount + 1
        }else{
            phoneNumberValidation.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
        }
       
     
       
        submitValidationresult = trueValiDationCount
    }
    
    
    func  ConvertfieldstoEmpty()  {
        emaiUserName.text=""
        passwordRegistration.text=""
        phoneNumberValidation.text=""
        userFirstname.text=""
        dobRegistraion.text=""
       lastNameUsers.text=""
        
    }
    //MARK:-SUBMITBUTTON
    @IBAction func SUBMITBUTTON(_ sender: Any) {
    
//        ListmultipledataValue()

        if submitValidationresult == 5 {
            submitvalidationresult()
        }else{
            scrollViewModify.setContentOffset(CGPoint(x: 0,y: 200), animated: true)
            submitErrorButton.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
        }
        if userFirstname.text! == Firstnamesubmitvalidation() {
           
           // print(TrueValidationCount)
        }else{
            userFirstname.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
        }
        if lastNameUsers.text! == Lastnamesubmitvalidation() {
           

        }else{
            lastNameUsers.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
        }
        if emaiUserName.text! == Emailsubmitvalidation() {
           
        }else{
            emaiUserName.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
        }
        if passwordRegistration.text! == Passwordsubmitvalidation() {
           
        }else{
            passwordRegistration.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
        }
        if dobRegistraion.text! == DOB() {
          
        }else{
            dobRegistraion.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
        }
        if phoneNumberValidation.text! == phonesubmitvalidation() {
           
        }else{
            phoneNumberValidation.isError(baseColor: UIColor.gray.cgColor, numberOfShakes: 10, revert: true)
        }
        UserDefultMultipleEmails()
        UserDefultMultipleUsername()
        DictionaryCreatingand()
        print(UserDefaults.standard.value(forKey: "DictionaryElement"))
       
    }
   //MARK:-UserDefultMultipleEmails()
    func UserDefultMultipleEmails()  {
        let ArrayStringEmail:[String] = [emaiUserName.text!]
        var dataEmail = UserDefaults.standard.value(forKey: "keyEmail") as? [String]
        if dataEmail?.count ?? 0 > 0 {
            dataEmail?.append(contentsOf: ArrayStringEmail)
            UserDefaults.standard.set(dataEmail, forKey: "keyEmail")
            
        }else{
            arrayStringEmail.append(contentsOf: ArrayStringEmail)
            UserDefaults.standard.set(arrayStringEmail, forKey: "keyEmail")
        }
    }
    //MARK:-UserDefultMultipleUsername()
    func UserDefultMultipleUsername()  {
        let ArrayStringUsername:[String] = [userFirstname.text!]
        var dataUsername = UserDefaults.standard.value(forKey: "keyUsername") as? [String]
        if dataUsername?.count ?? 0 > 0 {
            dataUsername?.append(contentsOf: ArrayStringUsername)
            UserDefaults.standard.set(dataUsername, forKey: "keyUsername")
            
        }else{
            arrayStringUsername.append(contentsOf: ArrayStringUsername)
            UserDefaults.standard.set(arrayStringUsername, forKey: "keyUsername")
        }
    }
    //MARK:-Dictionry Array
    func DictionaryCreatingand()
    {
       
        let dictinaryDataElementArray:[[String: Any]] = [["Email": emaiUserName.text!,"Username":userFirstname.text!,"Lastname": lastNameUsers.text!,"Phoneno": phoneNumberValidation.text!]]
        var dictinaryDataElement = UserDefaults.standard.value(forKey: "DictionaryElement") as? [[String: Any]]
        if dictinaryDataElement?.count ?? 0 > 0 {
            dictinaryDataElement?.append(contentsOf: dictinaryDataElementArray)
            UserDefaults.standard.set(dictinaryDataElement, forKey: "DictionaryElement")
            
        }else{
            dictinaryElementRegistration.append(contentsOf: dictinaryDataElementArray)
            UserDefaults.standard.set(dictinaryElementRegistration, forKey: "DictionaryElement")
        }
       
    }


    //MARK:-submitvalidationresult
    func submitvalidationresult() {
        let ResultofEmailId:String =  Emailsubmitvalidation()
      
        let ResultofPhoneId:String =  phonesubmitvalidation()
       
     
        let Firstnameresultsubmitvalidation:String =  Firstnamesubmitvalidation()
        print(Firstnameresultsubmitvalidation)
        let Lastnameresultsubmitvalidation:String =  Lastnamesubmitvalidation()
        print(Lastnameresultsubmitvalidation)
       
        let Passwordsubmitresultvalidation:String =  Passwordsubmitvalidation()
        print(Passwordsubmitresultvalidation)
        let DOBresult:String =  DOB()
       
    
        guard let secondviewController =  self.storyboard?.instantiateViewController(withIdentifier: "DetailVC") as? RegistrationDetailList else { return  }
  
        
        secondviewController.genderName = genderDetails
        secondviewController.emailName = ResultofEmailId
        secondviewController.phoneName = ResultofPhoneId
        secondviewController.passwordID = Passwordsubmitresultvalidation
        secondviewController.firstName = Firstnameresultsubmitvalidation
        secondviewController.lastName = Lastnameresultsubmitvalidation
        secondviewController.dobName = DOBresult
        secondviewController.hobbiesName = hobbiesArray
        secondviewController.genderName = genderDetails
        secondviewController.nationalityName = nationalitySelected
        secondviewController.workingName = areuWorkingSelected
           arrayString = [
        ResultofEmailId,Passwordsubmitresultvalidation,ResultofPhoneId,Firstnameresultsubmitvalidation,Lastnameresultsubmitvalidation,DOBresult
                       ,nationalitySelected
                        ,areuWorkingSelected,genderDetails]
      
        UserDefaults.standard.set(arrayString, forKey: "detailsValue")
        UserDefaults.standard.set(emaiUserName.text!, forKey:emaiUserName.text!)
        UserDefaults.standard.set(passwordRegistration.text!, forKey: ( passwordRegistration.text!))
        
       
      
      
   self.navigationController?.pushViewController(secondviewController, animated: true)
        

    }
   
    //MARK:-LoginPage_Action
    @IBAction func LoginPage_Action(_ sender: Any) {
     
    }
    //MARK:-datePickerChanged
    @IBAction func datePickerChanged(_ sender: UIDatePicker) {
        let DatePicker = DateFormatter()
        DatePicker.dateStyle=DateFormatter.Style.short
        let DateSet=DatePicker.string(from: sender.date)
        dobRegistraion.text = DateSet
        
    }
    //MARK:-SelectimageGallerry
    @IBAction func SelectimageGallerry(_ sender: UIButton) {
        let ImagePicker=UIImagePickerController()
        ImagePicker.allowsEditing=true
        ImagePicker.delegate = self
        let alert=UIAlertController(title: "Choose Image", message: "Select Image option", preferredStyle: .actionSheet)
                                     alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler:{ (_) in  ImagePicker.sourceType = .photoLibrary
                                        self.present(ImagePicker,animated: true)
                                     }))
                alert.addAction(UIAlertAction(title: "Camera", style: .default, handler:{ (_) in
                    ImagePicker.delegate = self
                    ImagePicker.sourceType = .camera
                  
                   self.present(ImagePicker,animated: true)
                }))
                alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: { (_) in
                       print("User click Dismiss button")
           
                   }))

                               self.present(alert, animated: true, completion: {
                                   print("completion block")
                               })
            }

}

//MARK:-extension
extension ViewController:UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        print("\(info)")
    
        Imageselection.layer.borderWidth=1.0
        Imageselection.layer.masksToBounds = false
     
        Imageselection.layer.cornerRadius = Imageselection.frame.size.height/2
        Imageselection.clipsToBounds = true

        Imageselection.image = info[.originalImage] as? UIImage

//        UserDefaults.standard.set((Imageselection ?? UIImage().pngData()), forKey: "Image")
        picker.dismiss(animated: true, completion: nil)
        let ArrayUIimageImage:[Data?] = [Imageselection.image?.pngData()]
        var dataImage = UserDefaults.standard.value(forKey: "arrayImage") as? [Data?]
        if dataImage?.count ?? 0 > 0 {
            dataImage?.append(contentsOf: ArrayUIimageImage)
            UserDefaults.standard.set(dataImage, forKey: "arrayImage")
            
        }else{
            arrayImageArray.append(contentsOf: ArrayUIimageImage)
            UserDefaults.standard.set(arrayImageArray, forKey: "arrayImage")
        }

      
    }

    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
extension UITextField {
    func isError(baseColor: CGColor, numberOfShakes shakes: Float, revert: Bool) {
        let animation: CABasicAnimation = CABasicAnimation(keyPath: "shadowColor")
        animation.fromValue = baseColor
        animation.toValue = UIColor.red.cgColor
        animation.duration = 0.4
        if revert { animation.autoreverses = true } else { animation.autoreverses = false }
        self.layer.add(animation, forKey: "")

        let shake: CABasicAnimation = CABasicAnimation(keyPath: "position")
        shake.duration = 0.07
        shake.repeatCount = shakes
        if revert { shake.autoreverses = true  } else { shake.autoreverses = false }
        shake.fromValue = NSValue(cgPoint: CGPoint(x: self.center.x - 10, y: self.center.y))
        shake.toValue = NSValue(cgPoint: CGPoint(x: self.center.x + 10, y: self.center.y))
        self.layer.add(shake, forKey: "position")
    }
}
extension UIImageView
{
    func isError(baseColor: CGColor, numberOfShakes shakes: Float, revert: Bool) {
        let animation: CABasicAnimation = CABasicAnimation(keyPath: "shadowColor")
        animation.fromValue = baseColor
        animation.toValue = UIColor.red.cgColor
        animation.duration = 0.4
        if revert { animation.autoreverses = true } else { animation.autoreverses = false }
        self.layer.add(animation, forKey: "")

        let shake: CABasicAnimation = CABasicAnimation(keyPath: "position")
        shake.duration = 0.07
        shake.repeatCount = shakes
        if revert { shake.autoreverses = true  } else { shake.autoreverses = false }
        shake.fromValue = NSValue(cgPoint: CGPoint(x: self.center.x - 10, y: self.center.y))
        shake.toValue = NSValue(cgPoint: CGPoint(x: self.center.x + 10, y: self.center.y))
        self.layer.add(shake, forKey: "position")
    }
}
extension UIButton
{
    func isError(baseColor: CGColor, numberOfShakes shakes: Float, revert: Bool) {
        let animation: CABasicAnimation = CABasicAnimation(keyPath: "shadowColor")
        animation.fromValue = baseColor
        animation.toValue = UIColor.red.cgColor
        animation.duration = 0.4
        if revert { animation.autoreverses = true } else { animation.autoreverses = false }
        self.layer.add(animation, forKey: "")

        let shake: CABasicAnimation = CABasicAnimation(keyPath: "position")
        shake.duration = 0.07
        shake.repeatCount = shakes
        if revert { shake.autoreverses = true  } else { shake.autoreverses = false }
        shake.fromValue = NSValue(cgPoint: CGPoint(x: self.center.x - 10, y: self.center.y))
        shake.toValue = NSValue(cgPoint: CGPoint(x: self.center.x + 10, y: self.center.y))
        self.layer.add(shake, forKey: "position")
    }
}
extension UITextField {

 /// set icon of 20x20 with left padding of 8px
 func setLeftIcon(_ icon: UIImage) {

    let padding = 8
    let size = 20

    let outerView = UIView(frame: CGRect(x: 0, y: 0, width: size+padding, height: size) )
    let iconView  = UIImageView(frame: CGRect(x: padding, y: 0, width: size, height: size))
    iconView.tintColor = UIColor.black
    iconView.image = icon
    
    outerView.addSubview(iconView)

    leftView = outerView
    leftViewMode = .always
  }
}
