//
//  TableViewController.swift
//  Avinash27try
//
//  Created by Satya on 13/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    var countNorows:Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()

  
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
     
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return 100
        
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: TableViewTableViewCell? = tableView.dequeueReusableCell(withIdentifier: "Cell") as? TableViewTableViewCell
      
        return cell!
        
    }


}
