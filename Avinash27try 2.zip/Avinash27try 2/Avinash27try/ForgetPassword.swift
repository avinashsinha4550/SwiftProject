//
//  ForgetPassword.swift
//  Avinash27try
//
//  Created by Satya on 09/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class ForgetPassword: UIViewController {

    @IBOutlet weak var Continue: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        Continue.layer.cornerRadius = Continue.bounds.size.height/2
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
