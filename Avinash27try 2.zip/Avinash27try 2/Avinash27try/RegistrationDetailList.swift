//
//  RegistrationDetailList.swift
//  Avinash27try
//
//  Created by Pulkit on 30/09/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class RegistrationDetailList: UIViewController {
    //MARK:-Variable
    var emailName:String?
    var phoneName:String?
    var passwordID:String?
    var firstName:String?
    var lastName:String?
    var dobName:String?
    var genderName:String?
    var hobbiesName:[String]?=[]
    var nationalityName:String?
    var workingName:String?
    //MARK:-IBOutlet
    @IBOutlet weak var workingSelected: UILabel!
    @IBOutlet weak var nationalitySelected: UILabel!
    @IBOutlet weak var iblphoneId: UILabel!
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var lblFirstName: UILabel!
    @IBOutlet weak var lblLastName: UILabel!
    @IBOutlet weak var dobDetails: UILabel!
    @IBOutlet weak var lblPassword: UILabel!
    @IBOutlet weak var loginPopViewController: UIButton!
    @IBOutlet weak var hobbiesSelected: UILabel!
    @IBOutlet weak var genderSelected: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let hobbiesConverter:String=hobbiesName?.joined(separator: " , ") ?? ""
        lbl?.text = emailName
        iblphoneId?.text = phoneName
        lblPassword?.text = passwordID
        lblFirstName?.text = firstName
        lblLastName?.text = lastName
        dobDetails?.text = dobName
        genderSelected?.text = genderName
        hobbiesSelected?.text = hobbiesConverter
        nationalitySelected?.text = nationalityName
        workingSelected?.text = workingName
       print(hobbiesSelected?.text ?? "")

    }
    
    
    @IBAction func PopviewController(_ sender: Any) {
//        let pop = self.storyboard?.instantiateViewController(withIdentifier: "LoginId") as? LoginViewController
        self.navigationController?.popToRootViewController(animated: true)
    }
    


}
