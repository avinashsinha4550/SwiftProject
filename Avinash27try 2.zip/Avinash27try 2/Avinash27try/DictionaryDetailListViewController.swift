//
//  DictionaryDetailListViewController.swift
//  Avinash27try
//
//  Created by Satya on 15/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class DictionaryDetailListViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
