//
//  PasswordChange.swift
//  Avinash27try
//
//  Created by Satya on 12/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class PasswordChange: UIViewController {
    @IBOutlet weak var enterNewPassword: UITextField!
    
    @IBOutlet weak var confirmPassword: UITextField!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        enterNewPassword.addDoneButtonOnKeyboard()
        confirmPassword.addDoneButtonOnKeyboard()
    }
    
    @IBAction func PasswordChangedSuccess(_ sender: Any) {
        if CheckingValid() {
            Alertmessagevalidation()
        }
        else
        {
            showSimpleAlert()
        }
        
    }
    func CheckingValid()->Bool
{
    if enterNewPassword.text! == confirmPassword.text!{
        UserDefaults.standard.set(confirmPassword.text!, forKey: "password")
        return true
    }
    else{
        return false
    }
        
}
    func showSimpleAlert() {
        let alert = UIAlertController(title: "Not Matching", message: " fields are not matching",         preferredStyle: UIAlertController.Style.alert)

        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
               //Cancel Action
           }))
           alert.addAction(UIAlertAction(title: "ok",
                                         style: UIAlertAction.Style.default,
                                         handler: {(_: UIAlertAction!) in
                                           //ok  action
           }))
           self.present(alert, animated: true, completion: nil)
       }
    func Alertmessagevalidation() {
        let alert = UIAlertController(title: "valdation Success", message: "\(UserDefaults.standard.string(forKey: "email") ?? "") is \(UserDefaults.standard.string(forKey: "password") ?? "")",         preferredStyle: UIAlertController.Style.alert)

        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
               //Cancel Action
           }))
           alert.addAction(UIAlertAction(title: "ok",
                                         style: UIAlertAction.Style.default,
                                         handler: {(_) in
                                            self.navigationController?.popToRootViewController(animated: true)
                                           //ok  action
           }))
           self.present(alert, animated: true, completion: nil)
       }
}
